from django.shortcuts import render, redirect
from .models import Laptop
from .forms import LaptopForm
from django.contrib.auth.decorators import login_required
# Create your views here.

from django.http import HttpResponse


def showlaptopsview(request):
    laptop_objects = Laptop.objects.all()
    template_name = "laptop/show_laptop.html"
    context = {"laptop_objects": laptop_objects}
    return render(request, template_name, context)

@login_required(login_url="/project/login/")
def addlaptopsview(request):
    if request.method == "GET":
        lap_form = LaptopForm()
        template_name = "laptop/add_laptops.html"
        context = {"lap_form": lap_form}
        return render(request, template_name, context)
    elif request.method == "POST":
        lap_filled_form = LaptopForm(request.POST, request.FILES)
        if lap_filled_form.is_valid():
            lap_filled_form.save()
            return redirect("/lapcart/show/")


@login_required(login_url="/project/login/")
def updatelaptopsview(request, i):
    laptop = Laptop.objects.get(id=i)
    if request.method == "GET":
        lap_update_form = LaptopForm(instance=laptop)
        template_name = "laptop/add_laptops.html"
        context = {"lap_form": lap_update_form}
        return render(request, template_name, context)
    elif request.method == "POST":
        lap_filled_form = LaptopForm(request.POST,request.FILES, instance=laptop)
        if lap_filled_form.is_valid():
            lap_filled_form.save()
            return redirect("/lapcart/show/")


@login_required(login_url="/project/login/")
def deletelaptopview(request, i):
    laptop = Laptop.objects.get(id=i)
    laptop.delete()
    return redirect("/lapcart/show/")
