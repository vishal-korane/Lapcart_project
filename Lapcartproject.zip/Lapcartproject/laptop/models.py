from django.db import models


# Create your models here.
class Laptop(models.Model):
    image = models.ImageField(upload_to='images/', null=True)
    company = models.CharField(max_length=50)
    model = models.CharField(max_length=50)
    ram = models.IntegerField()
    rom = models.IntegerField()
    price = models.FloatField()
