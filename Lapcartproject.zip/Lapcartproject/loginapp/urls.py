from django.urls import path
from .import views
urlpatterns = [
            path("register/", views.registerview),
            path("login/", views.loginview),
            path("logout/", views.logoutview)
]