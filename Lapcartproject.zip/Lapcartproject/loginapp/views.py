from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from django.shortcuts import render, redirect
from django.contrib.auth.forms import UserCreationForm


# Create your views here.

def registerview(request):
    if request.method == "GET":
        form = UserCreationForm()
        template_name = "loginapp/register.html"
        context = {"form": form}
        return render(request, template_name, context)
    elif request.method == "POST":
        form = UserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect("/project/login/")
        else:
            return render(request,'loginapp/register.html',{'form':form})



def loginview(request):
    if request.method == "GET":
        template_name = "loginapp/login.html"
        context = {}
        return render(request, template_name, context)
    if request.method == "POST":
        u = request.POST["un"]
        p = request.POST["pw"]
        user = authenticate(username=u, password=p)
        if user is not None:
            login(request, user)
            return redirect("/lapcart/show/")
        else:
            messages.add_message(request, messages.ERROR, "INVALID CREDENTIALS")
            return redirect("/project/login/")


def logoutview(request):
    logout(request)
    return redirect("/project/login/")
